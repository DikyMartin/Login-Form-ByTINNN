const teks1 = ['HALLO', 'MAU', 'LOGIN', '??'];

for(var i = 0; i < teks1.length; i++) {
        alert(teks1[i]);
}